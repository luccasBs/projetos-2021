﻿
namespace SnackMachine
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnMMS = new System.Windows.Forms.Button();
            this.btncoca = new System.Windows.Forms.Button();
            this.btnTwix = new System.Windows.Forms.Button();
            this.textValor = new System.Windows.Forms.TextBox();
            this.btnoreo = new System.Windows.Forms.Button();
            this.btnskittles = new System.Windows.Forms.Button();
            this.btnHersheys = new System.Windows.Forms.Button();
            this.btnfritos = new System.Windows.Forms.Button();
            this.btnlays = new System.Windows.Forms.Button();
            this.btndoritos = new System.Windows.Forms.Button();
            this.btnInserir = new System.Windows.Forms.Button();
            this.btnfinalizar = new System.Windows.Forms.Button();
            this.lblmms = new System.Windows.Forms.Label();
            this.lblcoca = new System.Windows.Forms.Label();
            this.lblTwix = new System.Windows.Forms.Label();
            this.lbloreo = new System.Windows.Forms.Label();
            this.lblskittles = new System.Windows.Forms.Label();
            this.lblhersheys = new System.Windows.Forms.Label();
            this.lblfritos = new System.Windows.Forms.Label();
            this.lbllays = new System.Windows.Forms.Label();
            this.lbldoritos = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(96, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(232, 40);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Snack Machine";
            // 
            // btnMMS
            // 
            this.btnMMS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnMMS.Enabled = false;
            this.btnMMS.Image = global::SnackMachine.Properties.Resources.mm2;
            this.btnMMS.Location = new System.Drawing.Point(32, 117);
            this.btnMMS.Name = "btnMMS";
            this.btnMMS.Size = new System.Drawing.Size(98, 54);
            this.btnMMS.TabIndex = 1;
            this.btnMMS.UseVisualStyleBackColor = true;
            this.btnMMS.Click += new System.EventHandler(this.btnMMS_Click);
            // 
            // btncoca
            // 
            this.btncoca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btncoca.Enabled = false;
            this.btncoca.Image = global::SnackMachine.Properties.Resources.coca;
            this.btncoca.Location = new System.Drawing.Point(162, 117);
            this.btncoca.Name = "btncoca";
            this.btncoca.Size = new System.Drawing.Size(98, 54);
            this.btncoca.TabIndex = 2;
            this.btncoca.UseVisualStyleBackColor = true;
            this.btncoca.Click += new System.EventHandler(this.btncoca_Click);
            // 
            // btnTwix
            // 
            this.btnTwix.Enabled = false;
            this.btnTwix.Image = global::SnackMachine.Properties.Resources.twix;
            this.btnTwix.Location = new System.Drawing.Point(287, 117);
            this.btnTwix.Name = "btnTwix";
            this.btnTwix.Size = new System.Drawing.Size(98, 54);
            this.btnTwix.TabIndex = 3;
            this.btnTwix.UseVisualStyleBackColor = true;
            this.btnTwix.Click += new System.EventHandler(this.btnTwix_Click);
            // 
            // textValor
            // 
            this.textValor.Location = new System.Drawing.Point(63, 75);
            this.textValor.Name = "textValor";
            this.textValor.Size = new System.Drawing.Size(299, 23);
            this.textValor.TabIndex = 4;
            // 
            // btnoreo
            // 
            this.btnoreo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnoreo.Enabled = false;
            this.btnoreo.Image = global::SnackMachine.Properties.Resources.MicrosoftTeams_image__1_;
            this.btnoreo.Location = new System.Drawing.Point(32, 214);
            this.btnoreo.Name = "btnoreo";
            this.btnoreo.Size = new System.Drawing.Size(98, 54);
            this.btnoreo.TabIndex = 4;
            this.btnoreo.UseVisualStyleBackColor = true;
            this.btnoreo.Click += new System.EventHandler(this.btnoreo_Click);
            // 
            // btnskittles
            // 
            this.btnskittles.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnskittles.Enabled = false;
            this.btnskittles.Image = global::SnackMachine.Properties.Resources.skittles;
            this.btnskittles.Location = new System.Drawing.Point(162, 214);
            this.btnskittles.Name = "btnskittles";
            this.btnskittles.Size = new System.Drawing.Size(98, 54);
            this.btnskittles.TabIndex = 6;
            this.btnskittles.UseVisualStyleBackColor = true;
            this.btnskittles.Click += new System.EventHandler(this.btnskittles_Click);
            // 
            // btnHersheys
            // 
            this.btnHersheys.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHersheys.Enabled = false;
            this.btnHersheys.Image = global::SnackMachine.Properties.Resources.hersheys;
            this.btnHersheys.Location = new System.Drawing.Point(287, 214);
            this.btnHersheys.Name = "btnHersheys";
            this.btnHersheys.Size = new System.Drawing.Size(98, 54);
            this.btnHersheys.TabIndex = 7;
            this.btnHersheys.UseVisualStyleBackColor = true;
            this.btnHersheys.Click += new System.EventHandler(this.btnHersheys_Click);
            // 
            // btnfritos
            // 
            this.btnfritos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnfritos.Enabled = false;
            this.btnfritos.Image = global::SnackMachine.Properties.Resources.fritos;
            this.btnfritos.Location = new System.Drawing.Point(32, 311);
            this.btnfritos.Name = "btnfritos";
            this.btnfritos.Size = new System.Drawing.Size(98, 54);
            this.btnfritos.TabIndex = 8;
            this.btnfritos.UseVisualStyleBackColor = true;
            this.btnfritos.Click += new System.EventHandler(this.btnfritos_Click);
            // 
            // btnlays
            // 
            this.btnlays.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnlays.Enabled = false;
            this.btnlays.Image = global::SnackMachine.Properties.Resources.lays;
            this.btnlays.Location = new System.Drawing.Point(162, 311);
            this.btnlays.Name = "btnlays";
            this.btnlays.Size = new System.Drawing.Size(98, 54);
            this.btnlays.TabIndex = 9;
            this.btnlays.UseVisualStyleBackColor = true;
            this.btnlays.Click += new System.EventHandler(this.btnlays_Click);
            // 
            // btndoritos
            // 
            this.btndoritos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btndoritos.Enabled = false;
            this.btndoritos.Image = global::SnackMachine.Properties.Resources.doritos;
            this.btndoritos.Location = new System.Drawing.Point(287, 311);
            this.btndoritos.Name = "btndoritos";
            this.btndoritos.Size = new System.Drawing.Size(98, 54);
            this.btndoritos.TabIndex = 10;
            this.btndoritos.UseVisualStyleBackColor = true;
            this.btndoritos.Click += new System.EventHandler(this.btndoritos_Click);
            // 
            // btnInserir
            // 
            this.btnInserir.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.btnInserir.Location = new System.Drawing.Point(63, 416);
            this.btnInserir.Name = "btnInserir";
            this.btnInserir.Size = new System.Drawing.Size(88, 31);
            this.btnInserir.TabIndex = 11;
            this.btnInserir.Text = "Inserir";
            this.btnInserir.UseVisualStyleBackColor = true;
            this.btnInserir.Click += new System.EventHandler(this.btnInserir_Click);
            // 
            // btnfinalizar
            // 
            this.btnfinalizar.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.btnfinalizar.Location = new System.Drawing.Point(274, 416);
            this.btnfinalizar.Name = "btnfinalizar";
            this.btnfinalizar.Size = new System.Drawing.Size(88, 31);
            this.btnfinalizar.TabIndex = 12;
            this.btnfinalizar.Text = "Finalizar";
            this.btnfinalizar.UseVisualStyleBackColor = true;
            this.btnfinalizar.Click += new System.EventHandler(this.btnfinalizar_Click);
            // 
            // lblmms
            // 
            this.lblmms.AutoSize = true;
            this.lblmms.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblmms.Location = new System.Drawing.Point(46, 174);
            this.lblmms.Name = "lblmms";
            this.lblmms.Size = new System.Drawing.Size(74, 25);
            this.lblmms.TabIndex = 13;
            this.lblmms.Text = "R$ 3,50";
            // 
            // lblcoca
            // 
            this.lblcoca.AutoSize = true;
            this.lblcoca.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblcoca.Location = new System.Drawing.Point(175, 174);
            this.lblcoca.Name = "lblcoca";
            this.lblcoca.Size = new System.Drawing.Size(76, 25);
            this.lblcoca.TabIndex = 14;
            this.lblcoca.Text = "R$ 5,00";
            // 
            // lblTwix
            // 
            this.lblTwix.AutoSize = true;
            this.lblTwix.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblTwix.Location = new System.Drawing.Point(300, 174);
            this.lblTwix.Name = "lblTwix";
            this.lblTwix.Size = new System.Drawing.Size(76, 25);
            this.lblTwix.TabIndex = 15;
            this.lblTwix.Text = "R$ 3,80";
            // 
            // lbloreo
            // 
            this.lbloreo.AutoSize = true;
            this.lbloreo.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbloreo.Location = new System.Drawing.Point(46, 271);
            this.lbloreo.Name = "lbloreo";
            this.lbloreo.Size = new System.Drawing.Size(78, 25);
            this.lbloreo.TabIndex = 16;
            this.lbloreo.Text = "R$ 4,00";
            // 
            // lblskittles
            // 
            this.lblskittles.AutoSize = true;
            this.lblskittles.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblskittles.Location = new System.Drawing.Point(175, 271);
            this.lblskittles.Name = "lblskittles";
            this.lblskittles.Size = new System.Drawing.Size(75, 25);
            this.lblskittles.TabIndex = 17;
            this.lblskittles.Text = "R$ 6,50";
            // 
            // lblhersheys
            // 
            this.lblhersheys.AutoSize = true;
            this.lblhersheys.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblhersheys.Location = new System.Drawing.Point(300, 271);
            this.lblhersheys.Name = "lblhersheys";
            this.lblhersheys.Size = new System.Drawing.Size(76, 25);
            this.lblhersheys.TabIndex = 18;
            this.lblhersheys.Text = "R$ 4,50";
            // 
            // lblfritos
            // 
            this.lblfritos.AutoSize = true;
            this.lblfritos.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblfritos.Location = new System.Drawing.Point(46, 368);
            this.lblfritos.Name = "lblfritos";
            this.lblfritos.Size = new System.Drawing.Size(77, 25);
            this.lblfritos.TabIndex = 19;
            this.lblfritos.Text = "R$ 2,00";
            // 
            // lbllays
            // 
            this.lbllays.AutoSize = true;
            this.lbllays.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbllays.Location = new System.Drawing.Point(175, 368);
            this.lbllays.Name = "lbllays";
            this.lbllays.Size = new System.Drawing.Size(75, 25);
            this.lbllays.TabIndex = 20;
            this.lbllays.Text = "R$ 7,50";
            // 
            // lbldoritos
            // 
            this.lbldoritos.AutoSize = true;
            this.lbldoritos.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbldoritos.Location = new System.Drawing.Point(300, 368);
            this.lbldoritos.Name = "lbldoritos";
            this.lbldoritos.Size = new System.Drawing.Size(77, 25);
            this.lbldoritos.TabIndex = 21;
            this.lbldoritos.Text = "R$ 7,00";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 470);
            this.Controls.Add(this.lbldoritos);
            this.Controls.Add(this.lbllays);
            this.Controls.Add(this.lblfritos);
            this.Controls.Add(this.lblhersheys);
            this.Controls.Add(this.lblskittles);
            this.Controls.Add(this.lbloreo);
            this.Controls.Add(this.lblTwix);
            this.Controls.Add(this.lblcoca);
            this.Controls.Add(this.lblmms);
            this.Controls.Add(this.btnfinalizar);
            this.Controls.Add(this.btnInserir);
            this.Controls.Add(this.btndoritos);
            this.Controls.Add(this.btnlays);
            this.Controls.Add(this.btnfritos);
            this.Controls.Add(this.btnHersheys);
            this.Controls.Add(this.btnskittles);
            this.Controls.Add(this.btnoreo);
            this.Controls.Add(this.textValor);
            this.Controls.Add(this.btnTwix);
            this.Controls.Add(this.btncoca);
            this.Controls.Add(this.btnMMS);
            this.Controls.Add(this.lblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnMMS;
        private System.Windows.Forms.Button btncoca;
        private System.Windows.Forms.Button btnTwix;
        private System.Windows.Forms.TextBox textValor;
        private System.Windows.Forms.Button btnoreo;
        private System.Windows.Forms.Button btnskittles;
        private System.Windows.Forms.Button btnHersheys;
        private System.Windows.Forms.Button btnfritos;
        private System.Windows.Forms.Button btnlays;
        private System.Windows.Forms.Button btndoritos;
        private System.Windows.Forms.Button btnInserir;
        private System.Windows.Forms.Button btnfinalizar;
        private System.Windows.Forms.Label lblmms;
        private System.Windows.Forms.Label lblcoca;
        private System.Windows.Forms.Label lblTwix;
        private System.Windows.Forms.Label lbloreo;
        private System.Windows.Forms.Label lblskittles;
        private System.Windows.Forms.Label lblhersheys;
        private System.Windows.Forms.Label lblfritos;
        private System.Windows.Forms.Label lbllays;
        private System.Windows.Forms.Label lbldoritos;
    }
}